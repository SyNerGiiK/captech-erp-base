import React, { useEffect, useState } from "react";

const apiBase = (import.meta.env.VITE_USE_PROXY === "1")
  ? "/api"
  : (import.meta.env.VITE_API_URL ?? "http://localhost:8000");

export default function Invoices() {
  const [items, setItems] = useState([]);
  const [sel, setSel] = useState(null);
  const [loading, setLoading] = useState(false);
  const [vat, setVat] = useState(20);

  const session = (()=>{
  try { return JSON.parse(localStorage.getItem("session") || "null"); } catch { return null; }
})();
const auth = (()=>{
  try { return JSON.parse(localStorage.getItem("auth") || "null"); } catch { return null; }
})();
const token = (session?.token) || (auth?.token) || (localStorage.getItem("token") || "");


  async function refresh() {
    if (!token) { setItems([]); alert("Connecte-toi dans l\u2019onglet Auth, puis reviens ici."); return; }
    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/invoices/list?limit=50&offset=0`, {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const rows = Array.isArray(data) ? data : (data.items ?? []);
      setItems(rows);
      if (rows.length && !sel) setSel(rows[0]);
    } catch (e) {
      console.error("refresh invoices failed", e);
      alert("Impossible de charger les factures (voir console).");
    } finally {
      setLoading(false);
    }
  }

  async function downloadPdf() {
    if (!sel?.id) { alert("Sélectionne une facture."); return; }
    try {
      const res = await fetch(`${apiBase}/invoices/by-id/${sel.id}/public_url`, {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json(); // { path, token }
      const url = `${apiBase}${data.path}?token=${encodeURIComponent(data.token)}&vat_percent=${encodeURIComponent(vat)}`;
      window.open(url, "_blank", "noopener");
    } catch (e) {
      console.error("download pdf failed", e);
      alert("Téléchargement PDF impossible.");
    }
  }

  useEffect(() => { refresh(); /* eslint-disable-next-line */ }, []);

  return (
    <div style={{ padding: 16 }}>
      <h2>Factures</h2>
      <div style={{ marginBottom: 12, display: "flex", gap: 8, alignItems: "center" }}>
        <button onClick={refresh} disabled={loading}>Rafraîchir</button>
        <label>TVA %:&nbsp;
          <input type="number" min="0" max="25" value={vat} onChange={e => setVat(e.target.value)} style={{ width: 64 }} />
        </label>
        <button onClick={downloadPdf} disabled={!sel}>Télécharger (PDF)</button>
      </div>

      {loading && <p>Chargement…</p>}

      {!loading && items.length === 0 && (
        <p>Aucune facture. Crée une facture depuis l’API (/docs) ou via le seed.</p>
      )}

      {!loading && items.length > 0 && (
        <table border="1" cellPadding="6" style={{ borderCollapse: "collapse", width: "100%" }}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Numéro</th>
              <th>Titre</th>
              <th>Statut</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {items.map(it => (
              <tr key={it.id}
                  onClick={() => setSel(it)}
                  style={{ background: sel?.id === it.id ? "#eef" : "transparent", cursor: "pointer" }}>
                <td>{it.id}</td>
                <td>{it.number}</td>
                <td>{it.title}</td>
                <td>{it.status}</td>
                <td>{(it.total_cents ?? 0) / 100} €</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
